from django.contrib.auth.decorators import login_required, user_passes_test
from django.shortcuts import get_object_or_404
from django.utils.decorators import method_decorator
from django.views.generic.edit import FormView
from django.views.generic.base import TemplateView
from django.views.generic.detail import DetailView
from .models import Diagnostico
from .forms import PreguntasPruebaForm, PreguntasPruebaFormSet
from .models import PreguntasPrueba, PoolPreguntas, Pregunta
import datetime


@method_decorator(login_required, name='dispatch')
class PresentarView(FormView):
    """
    Vista de presentacion de una prueba. Contiene un formset de preguntas.
    Esta protegida para que solo los que hayan iniciado sesion puedan verla
    """
    template_name = 'diagnostico_presentar.html'
    form_class = PreguntasPruebaFormSet
    initial = []

    def get(self, request, *args, **kwargs):
        """
        Metodo para mostrar el formulario de presentacion de una prueba.
        """
        # obtenemos como parametro el banco del cual armar la prueba
        banco = int(request.GET.get('banco', '1'))

        # obtenemos el objeto a usar
        banco = get_object_or_404(PoolPreguntas, pk=banco)

        # creamos una prueba diagnostico
        self.diagnostico = Diagnostico.objects.create(
            usuario=request.user, banco=banco)

        # obtenemos un queryset de preguntas aleatorias del pool dado, limitado a 20
        self.preguntas_qs = Pregunta.objects.filter(
            pool=self.diagnostico.banco).order_by('?').distinct()[:20]
        self.preguntas = []
        for pregunta in self.preguntas_qs:
            # iteramos sobre ellas y las agregamos a la prueba que estamos llenando
            self.preguntas.append(PreguntasPrueba.objects.create(
                prueba=self.diagnostico, pregunta=pregunta))
        self.diagnostico.refresh_from_db()

        return super(PresentarView, self).get(request, *args, **kwargs)

    def form_valid(self, form):
        """
        En caso de que el formulario sea valido, lo guardamos
        """
        form.save()
        return super(PresentarView, self).form_valid(form)

    def get_initial(self):
        initial = super(PresentarView, self).get_initial()
        initial.extend([{'pregunta': pregunta} for pregunta in self.preguntas])
        return initial

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['formset'] = context.pop('form')
        return context

    def get_form_kwargs(self):
        kwargs = super().get_form_kwargs()
        kwargs['queryset'] = self.diagnostico.preguntas_usadas.all()
        return kwargs


class DiagnosticoDetailView(DetailView):
    model = Diagnostico
    template_name = "diagnostico_detail.html"

    @method_decorator(login_required)
    def get_context_data(self, **kwargs):
        prueba = get_object_or_404(Diagnostico, pk=kwargs['pk'])
        context = super().get_context_data(**kwargs)
        context['prueba'] = prueba
        return context
