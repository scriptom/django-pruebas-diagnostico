from django.apps import AppConfig


class DiagnosticosConfig(AppConfig):
    name = 'diagnosticos'
